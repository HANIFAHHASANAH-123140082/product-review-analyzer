from models import Base
from sqlalchemy import create_engine
import os
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.environ.get('DATABASE_URL')
print(f"Connecting to: {DATABASE_URL}")

engine = create_engine(DATABASE_URL)
Base.metadata.create_all(engine)

print("✅ Database tables created successfully!")