from dotenv import load_dotenv

# Load environment variables
load_dotenv()
load_dotenv()
from pyramid.view import view_config
from pyramid.response import Response
import requests
import google.generativeai as genai
import json
import os
from models import Review

# Load API keys from environment
HF_API_TOKEN = os.environ.get('HF_API_TOKEN', 'your-huggingface-token-here')
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', 'your-gemini-key-here')

# Configure Gemini
genai.configure(api_key=GEMINI_API_KEY)

def call_huggingface_sentiment(text):
    """Call Hugging Face API untuk sentiment analysis"""
    API_URL = "https://api-inference.huggingface.co/models/distilbert-base-uncased-finetuned-sst-2-english"
    headers = {"Authorization": f"Bearer {HF_API_TOKEN}"}
    
    try:
        response = requests.post(
            API_URL,
            headers=headers,
            json={"inputs": text},
            timeout=30
        )
        
        if response.status_code == 200:
            result = response.json()
            return {
                'label': result[0][0]['label'],
                'score': result[0][0]['score']
            }
        else:
            return {'label': 'UNKNOWN', 'score': 0.0}
    except Exception as e:
        print(f"Hugging Face API Error: {str(e)}")
        return {'label': 'ERROR', 'score': 0.0}


def extract_key_points_gemini(text):
    """Extract key points menggunakan Gemini"""
    try:
        model = genai.GenerativeModel('gemini-1.5-flash')
        
        prompt = f"""
Analyze this product review and extract the key points in JSON format.
Return ONLY a JSON array of key points (positive and negative aspects).

Example format:
["Great battery life", "Fast performance", "Expensive price", "Poor customer service"]

Review: {text}

Return only the JSON array, nothing else.
"""
        
        response = model.generate_content(prompt)
        text_response = response.text.strip()
        
        # Clean response (remove markdown if any)
        if text_response.startswith("```"):
            text_response = text_response.split("```")[1]
            if text_response.startswith("json"):
                text_response = text_response[4:]
        text_response = text_response.strip()
        
        # Parse JSON
        key_points = json.loads(text_response)
        return key_points
        
    except Exception as e:
        print(f"Gemini API Error: {str(e)}")
        return ["Error extracting key points"]


@view_config(route_name='analyze_review', request_method='POST', renderer='json')
def analyze_review(request):
    """POST /api/analyze-review - Analyze new product review"""
    try:
        # Get data from request
        data = request.json_body
        product_name = data.get('product_name', '').strip()
        review_text = data.get('review_text', '').strip()
        
        # Validation
        if not product_name:
            return {'error': 'Product name is required'}, 400
        if not review_text:
            return {'error': 'Review text is required'}, 400
        if len(review_text) < 10:
            return {'error': 'Review text too short (minimum 10 characters)'}, 400
        
        # Step 1: Sentiment Analysis (Hugging Face)
        print("Calling Hugging Face API...")
        sentiment_result = call_huggingface_sentiment(review_text)
        
        # Step 2: Extract key points (Gemini)
        print("Calling Gemini API...")
        key_points = extract_key_points_gemini(review_text)
        
        # Step 3: Save to database
        review = Review(
            product_name=product_name,
            review_text=review_text,
            sentiment=sentiment_result['label'],
            confidence=sentiment_result['score'],
            key_points=json.dumps(key_points)
        )
        
        request.dbsession.add(review)
        request.dbsession.flush()  # Get the ID
        
        print(f"Review saved with ID: {review.id}")
        
        return {
            'success': True,
            'id': review.id,
            'product_name': product_name,
            'sentiment': sentiment_result['label'],
            'confidence': round(sentiment_result['score'], 4),
            'key_points': key_points,
            'message': 'Review analyzed successfully!'
        }
        
    except Exception as e:
        print(f"Error in analyze_review: {str(e)}")
        request.response.status = 500
        return {'error': f'Server error: {str(e)}'}


@view_config(route_name='get_reviews', request_method='GET', renderer='json')
def get_reviews(request):
    """GET /api/reviews - Get all reviews"""
    try:
        # Query all reviews, sorted by newest first
        reviews = request.dbsession.query(Review)\
            .order_by(Review.created_at.desc())\
            .all()
        
        # Convert to list of dicts
        reviews_list = []
        for review in reviews:
            review_dict = review.to_dict()
            # Parse key_points JSON string
            try:
                review_dict['key_points'] = json.loads(review.key_points) if review.key_points else []
            except:
                review_dict['key_points'] = []
            reviews_list.append(review_dict)
        
        return {
            'success': True,
            'count': len(reviews_list),
            'reviews': reviews_list
        }
        
    except Exception as e:
        print(f"Error in get_reviews: {str(e)}")
        request.response.status = 500
        return {'error': f'Server error: {str(e)}'}


@view_config(route_name='home', request_method='GET', renderer='json')
def home(request):
    """Health check endpoint"""
    return {
        'status': 'OK',
        'message': 'Product Review Analyzer API is running!',
        'endpoints': {
            'POST /api/analyze-review': 'Analyze a new review',
            'GET /api/reviews': 'Get all reviews'
        }
    }