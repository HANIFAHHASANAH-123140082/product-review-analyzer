from pyramid.config import Configurator
from sqlalchemy import engine_from_config, create_engine
from sqlalchemy.orm import sessionmaker
import os

def main(global_config, **settings):
    """Main application configuration"""
    
    # Database configuration
    DATABASE_URL = os.environ.get(
        'DATABASE_URL',
        'postgresql://postgres:postgres@localhost/review_analyzer'
    )
    
    engine = create_engine(DATABASE_URL)
    session_factory = sessionmaker(bind=engine)
    
    # Create Pyramid config
    config = Configurator(settings=settings)
    
    # Add database session to request
    def add_db_session(request):
        session = session_factory()
        request.add_finished_callback(lambda req: session.close())
        return session
    
    config.add_request_method(add_db_session, 'dbsession', reify=True)
    
    # Enable CORS
    config.add_tween('pyramid_cors.tween_factory')
    
    # Include routes
    config.include('.routes')
    
    # Scan for views
    config.scan()
    
    return config.make_wsgi_app()


if __name__ == '__main__':
    from waitress import serve
    from models import Base
    from sqlalchemy import create_engine
    
    # Create database tables
    DATABASE_URL = os.environ.get(
        'DATABASE_URL',
        'postgresql://postgres:postgres@localhost/review_analyzer'
    )
    
    print("Creating database tables...")
    engine = create_engine(DATABASE_URL)
    Base.metadata.create_all(engine)
    print("Database tables created!")
    
    # Start server
    print("\n🚀 Starting server at http://localhost:6543")
    print("Press Ctrl+C to stop\n")
    
    app = main({})
    serve(app, host='0.0.0.0', port=6543)
```

5. **Ctrl + S**

✅ **File 5 selesai!**

---

## 🎉 HASIL AKHIR

Sekarang struktur folder Anda harusnya seperti ini:
```
product-review-analyzer/
└── backend/
    ├── __init__.py          ✅
    ├── models.py            ✅
    ├── routes.py            ✅
    ├── views.py             ✅
    └── requirements.txt     ✅